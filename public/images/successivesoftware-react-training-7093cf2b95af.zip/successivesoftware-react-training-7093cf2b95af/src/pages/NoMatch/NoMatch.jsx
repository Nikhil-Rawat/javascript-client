import React from 'react';
import PropTypes from 'prop-types';

import { Typography } from '@material-ui/core';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  mainContainer: {
    marginTop: theme.spacing.unit * 5,
  },
});

const propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
};

const NotFound = (props) => {
  const { classes } = props;

  return (
    <div className={classes.mainContainer}>
      <Typography component="h1" variant="h2" align="center" color="textPrimary" gutterBottom>
        Not Found
      </Typography>
      <Typography variant="h6" align="center" color="textSecondary" component="p">
        Seems like the page you are looking after does not exist.
      </Typography>
    </div>
  );
};


NotFound.propTypes = propTypes;

export default withStyles(styles)(NotFound);
