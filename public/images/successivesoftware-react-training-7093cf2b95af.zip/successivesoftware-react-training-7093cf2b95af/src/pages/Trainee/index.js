export { default as Trainee } from './Trainee';
