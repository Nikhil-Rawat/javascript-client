import React, { Component } from 'react';
import PropTypes from 'prop-types';

import {
  Button,
} from '@material-ui/core';
import withStyles from '@material-ui/core/styles/withStyles';

import { AddDialog } from './components';

const styles = theme => ({
  main: {
    marginTop: theme.spacing.unit * 2,
  },
});

const propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
};
class Trainee extends Component {
  state = {
    open: false,
  };

  handleClickOpen = () => {
    this.setState({ open: true });
  }

  handleClose = () => {
    this.setState({ open: false });
  }

  handleUser = (data) => {
    console.log(data);
    this.setState({ open: false });
  }

  render() {
    const { classes } = this.props;
    const { open } = this.state;
    return (
      <>
        <main className={classes.main}>
          <Button
            variant="outlined"
            color="primary"
            onClick={this.handleClickOpen}
          >
            Add Trainee
          </Button>
        </main>

        <AddDialog
          open={open}
          onClose={this.handleClose}
          onSubmit={this.handleUser}
        />
      </>
    );
  }
}

Trainee.propTypes = propTypes;

export default withStyles(styles)(Trainee);
