import React, { Component } from 'react';
import PropTypes from 'prop-types';

import {
  Avatar,
  Button,
  CssBaseline,
  Grid,
  InputAdornment,
  Paper,
  TextField,
  Typography,
} from '@material-ui/core';

import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import EmailIcon from '@material-ui/icons/Email';
import VisibilityOffIcon from '@material-ui/icons/VisibilityOff';

import withStyles from '@material-ui/core/styles/withStyles';
import * as yup from 'yup';

const styles = theme => ({
  main: {
    width: 'auto',
    display: 'block',
    marginLeft: theme.spacing.unit * 3,
    marginRight: theme.spacing.unit * 3,
    [theme.breakpoints.up(400 + theme.spacing.unit * 3 * 2)]: {
      width: 400,
      marginLeft: 'auto',
      marginRight: 'auto',
    },
  },
  paper: {
    marginTop: theme.spacing.unit * 8,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: `${theme.spacing.unit * 2}px ${theme.spacing.unit * 3}px ${theme
      .spacing.unit * 3}px`,
  },
  avatar: {
    margin: theme.spacing.unit,
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    marginTop: theme.spacing.unit * 2,
  },
  submit: {
    marginTop: theme.spacing.unit * 2,
  },
});

const loginSchema = yup.object({
  email: yup.string().email().required().label('Email Address'),
  password: yup.string().required('Password is required'),
});

class Login extends Component {
  state = {
    errors: {},
    touched: {},
    email: '',
    password: '',
  }

  handleSubmit = () => {
    const {
      email,
      password,
    } = this.state;

    console.log({
      email,
      password,
    });
  }

  handleBlur = field => () => {
    const { touched } = this.state;
    touched[field] = true;

    this.setState({
      touched,
    }, () => this.handleValidate());
  }

  handleValidate = () => {
    const {
      email,
      password,
    } = this.state;

    loginSchema.validate({
      email,
      password,
    }, { abortEarly: false })
      .then(() => {
        this.handleErrors(null);
      })
      .catch((errors) => {
        this.handleErrors(errors);
      });
  }

  handleErrors = (errors) => {
    const parsedErrors = {};
    if (errors) {
      errors.inner.forEach((error) => {
        parsedErrors[error.path] = error.message;
      });
    }

    this.setState({
      errors: parsedErrors,
    });
  }

  handleChange = field => (e) => {
    this.setState({
      [field]: e.target.value,
    }, this.handleValidate);
  }

  getError = (field) => {
    const { errors, touched } = this.state;

    if (!touched[field]) {
      return null;
    }

    return errors[field] || '';
  }

  hasErrors = () => {
    const { errors } = this.state;
    return Object.keys(errors).length !== 0;
  }

  isTouched = () => {
    const { touched } = this.state;
    return Object.keys(touched).length !== 0;
  }

  renderField = ({
    field,
    label,
    type,
    icon,
    value,
  }) => (
    <TextField
      variant="outlined"
      label={label}
      type={type}
      value={value}
      fullWidth
      onChange={this.handleChange(field)}
      onBlur={this.handleBlur(field)}
      error={!!this.getError(field)}
      helperText={this.getError(field)}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            {icon}
          </InputAdornment>
        ),
      }}
    />
  );

  render() {
    const { classes } = this.props;
    const { email, password } = this.state;

    return (
      <main className={classes.main}>
        <CssBaseline />
        <Paper className={classes.paper}>
          <Avatar className={classes.avatar}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5" gutterBottom>
            Login
          </Typography>
          <Grid container spacing={24} className={classes.form}>
            <Grid item xs={12}>
              {
                this.renderField({
                  label: 'Email Address',
                  field: 'email',
                  icon: <EmailIcon />,
                  type: 'text',
                  value: email,
                })
              }
            </Grid>
            <Grid item xs={12}>
              {
                this.renderField({
                  label: 'Password',
                  field: 'password',
                  icon: <VisibilityOffIcon />,
                  type: 'password',
                  value: password,
                })
              }
            </Grid>
            <Grid item xs={12}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                className={classes.submit}
                disabled={this.hasErrors() || !this.isTouched()}
              >
                Sign in
              </Button>
            </Grid>
          </Grid>
        </Paper>
      </main>
    );
  }
}

Login.propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
};

export default withStyles(styles)(Login);
