import React from 'react';

import { Slider, TextField } from '../../components';

export default () => (
  <>
    <Slider
      banners={[
        'banners/cloud.jpg',
        'banners/js.jpg',
        'banners/load-balancer.png',
        'banners/full-stack-web-development.jpg',
      ]}
      height={300}
    />

    <div>
      <h4>This is a Disabled Input</h4>
      <TextField disabled value="Disabled Input" />
    </div>
    <div>
      <h4>A Valid Input</h4>
      <TextField value="Accessible" />
    </div>
    <div>
      <h4>An Input with errors</h4>
      <TextField value="101" error="Could not be greater than" />
    </div>
  </>
);
