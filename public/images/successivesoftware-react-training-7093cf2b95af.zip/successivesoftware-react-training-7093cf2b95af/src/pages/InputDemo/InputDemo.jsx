import React, { Component } from 'react';
import * as yup from 'yup';

import {
  Button,
  SelectField,
  TextField,
  RadioGroup,
} from '../../components';

import {
  SPORT_CRICKET,
  SPORT_FOOTBALL,
  sports,
  cricketOptions,
  footballOptions,
} from '../../configs/constants';

import style from './style';

const playerSchema = yup.object({
  name: yup.string().required().label('Name'),
  sport: yup.string().required().label('Sport'),
  football: yup.string().label('What you do').when('sport', {
    is: val => val === 'football',
    then: yup.string().required(),
    otherwise: yup.string().min(0),
  }),
  cricket: yup.string().label('What you do').when('sport', {
    is: val => val === 'cricket',
    then: yup.string().required(),
    otherwise: yup.string().min(0),
  }),
});

class InputDemo extends Component {
  constructor(props) {
    super(props);

    this.state = {
      errors: {},
      touched: {},
      name: '',
      sport: '',
      cricket: '',
      football: '',
    };
  }

  handleBlur = field => () => {
    const { touched } = this.state;
    touched[field] = true;

    this.setState({
      touched,
    }, () => this.handleValidate());
  }

  handleValidate = () => {
    const {
      name,
      sport,
      football,
      cricket,
    } = this.state;

    playerSchema.validate({
      name,
      sport,
      football,
      cricket,
    }, { abortEarly: false })
      .then(() => {
        this.handleErrors(null);
      })
      .catch((errors) => {
        this.handleErrors(errors);
      });
  }

  handleErrors = (errors) => {
    const parsedErrors = {};
    if (errors) {
      errors.inner.forEach((error) => {
        parsedErrors[error.path] = error.message;
      });
    }

    this.setState({
      errors: parsedErrors,
    });
  }

  handleChange = field => (e) => {
    this.setState({
      [field]: e.target.value,
    }, () => this.handleValidate());
  }

  handleSportsChange = (e) => {
    this.setState({
      sport: e.target.value,
      football: '',
      cricket: '',
    }, () => this.handleValidate());
  }

  getError = (field) => {
    const { errors, touched } = this.state;
    console.log(touched, errors, field, touched[field], errors[field]);

    if (!touched[field]) {
      return null;
    }

    return errors[field] || '';
  }


  renderFootball = () => {
    const {
      football,
      sport,
    } = this.state;

    if (sport !== SPORT_FOOTBALL) {
      return null;
    }

    return (
      <div>
        <h4>What you do? *</h4>
        <RadioGroup
          onBlur={this.handleBlur('football')}
          onChange={this.handleChange('football')}
          value={football}
          options={footballOptions}
          error={this.getError('football')}
        />
      </div>
    );
  }

  renderCricket = () => {
    const {
      sport,
      cricket,
    } = this.state;

    if (sport !== SPORT_CRICKET) {
      return null;
    }

    return (
      <div>
        <h4>What you do? *</h4>
        <RadioGroup
          onBlur={this.handleBlur('cricket')}
          onChange={this.handleChange('cricket')}
          value={cricket}
          options={cricketOptions}
          error={this.getError('cricket')}
        />
      </div>
    );
  }

  hasErrors = () => {
    const { errors } = this.state;
    return Object.keys(errors).length !== 0;
  }

  isTouched = () => {
    const { touched } = this.state;
    return Object.keys(touched).length !== 0;
  }

  render() {
    const {
      name,
      sport,
    } = this.state;
    return (
      <>
        <div>
          <h4>Name *</h4>
          <TextField
            onBlur={this.handleBlur('name')}
            onChange={this.handleChange('name')}
            value={name}
            error={this.getError('name')}
          />
        </div>
        <div>
          <h4>Select the game you play? *</h4>
          <SelectField
            onChange={this.handleSportsChange}
            value={sport}
            options={sports}
            onBlur={this.handleBlur('sport')}
            error={this.getError('sport')}
          />
        </div>
        {this.renderFootball()}
        {this.renderCricket()}
        <p style={style.buttonGroup}>
          <Button value="Cancel" onClick={() => {}} />
          <Button
            onClick={() => {}}
            style={style.buttonMargin}
            value="Submit"
            color="primary"
            disabled={this.hasErrors() || !this.isTouched()}
          />
        </p>
      </>
    );
  }
}

export default InputDemo;
