export default {
  buttonGroup: {
    textAlign: 'right',
  },
  buttonMargin: {
    marginLeft: '10px',
  },
};
