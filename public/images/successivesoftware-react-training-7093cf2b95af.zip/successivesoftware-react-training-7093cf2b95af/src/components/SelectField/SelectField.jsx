import React from 'react';
import PropTypes from 'prop-types';

import style from './style';

const defaultProps = {
  error: '',
  options: [],
  defaultText: 'Select',
};

const propTypes = {
  error: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.shape({
    label: PropTypes.string,
    value: PropTypes.string,
  })),
  defaultText: PropTypes.string,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};

const SelectField = (props) => {
  const {
    error,
    options,
    defaultText,
    ...rest
  } = props;

  const errorStyle = error ? style.errorInput : {};

  return (
    <>
      <select style={{ ...style.base, ...errorStyle }} type="text" {...rest}>
        <option value="">{defaultText}</option>
        {
          options.map(option => (
            <option value={option.value} key={option.value}>{option.label}</option>
          ))
        }
      </select>
      {
        error && (
          <div style={style.error}>{error}</div>
        )
      }
    </>
  );
};

SelectField.defaultProps = defaultProps;
SelectField.propTypes = propTypes;

export default SelectField;
