export default {
  img: {
    maxHeight: '100%',
  },
  bannerContainer: {
    textAlign: 'center',
    backgroundColor: '#f9f9f9',
  },
};
