import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { getRandomNumber, getNextRoundRobin } from '../../lib/utils';
import style from './style';

import { PUBLIC_IMAGE_FOLDER, DEFAULT_BANNER_IMAGE } from '../../configs/constants';

const propTypes = {
  altText: PropTypes.string,
  banners: PropTypes.arrayOf(PropTypes.string),
  defaultBanner: PropTypes.string,
  duration: PropTypes.number,
  height: PropTypes.number,
  random: PropTypes.bool,
};

const defaultProps = {
  altText: 'Default Banner',
  banners: [],
  defaultBanner: DEFAULT_BANNER_IMAGE,
  duration: 2000,
  height: 200,
  random: false,
};

class Slider extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selected: 0,
    };

    this.bannerTimeout = null;
  }

  componentDidMount() {
    if (this.isBannerAvailable()) {
      const { duration } = this.props;
      this.bannerInterval = setInterval(() => this.setNextBanner(), duration);
    }
  }

  componentWillUnmount() {
    clearInterval(this.bannerInterval);
  }

  setNextBanner() {
    const { selected } = this.state;
    const { banners, random } = this.props;

    const nextBanner = random
      ? getRandomNumber(banners.length)
      : getNextRoundRobin(banners.length, selected);

    this.setState({
      selected: nextBanner,
    });
  }

  isBannerAvailable() {
    const { banners } = this.props;
    return Array.isArray(banners) && banners.length;
  }

  renderBanner(image) {
    const { height, altText } = this.props;
    const bannerStyle = { ...style.bannerContainer, height };
    return (
      <div style={bannerStyle}>
        <img src={`${PUBLIC_IMAGE_FOLDER}${image}`} alt={altText} style={style.img} />
      </div>
    );
  }

  render() {
    const { selected } = this.state;
    const { banners, defaultBanner } = this.props;

    if (!this.isBannerAvailable()) {
      return this.renderBanner(defaultBanner);
    }

    return this.renderBanner(banners[selected]);
  }
}

Slider.defaultProps = defaultProps;
Slider.propTypes = propTypes;

export default Slider;
