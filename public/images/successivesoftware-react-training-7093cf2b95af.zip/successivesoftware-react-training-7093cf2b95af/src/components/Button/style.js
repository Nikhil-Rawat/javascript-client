export default {
  base: {
    padding: '12px',
    border: '1px solid grey',
    borderRadius: '4px',
    boxSizing: 'border-box',
    marginBottom: '5px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  primary: {
    borderColor: '#4CAF50',
    backgroundColor: '#4CAF50',
    color: '#fff',
    cursor: 'pointer',
  },
};
