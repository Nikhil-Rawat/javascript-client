import React from 'react';
import PropTypes from 'prop-types';

import btnStyle from './style';

const defaultProps = {
  disabled: false,
  color: 'default',
  style: {},
};

const propTypes = {
  color: PropTypes.oneOf(['default', 'primary']),
  disabled: PropTypes.bool,
  style: PropTypes.objectOf(PropTypes.string),
  value: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};

const Button = (props) => {
  const {
    color,
    disabled,
    style,
    ...rest
  } = props;

  const buttonColorStyle = (color === 'default' || !btnStyle[color] || disabled)
    ? {}
    : btnStyle[color];

  return (
    <input
      style={{ ...btnStyle.base, ...buttonColorStyle, ...style }}
      type="button"
      disabled={disabled}
      {...rest}
    />
  );
};

Button.defaultProps = defaultProps;
Button.propTypes = propTypes;

export default Button;
