export { default as Math } from './Math';
