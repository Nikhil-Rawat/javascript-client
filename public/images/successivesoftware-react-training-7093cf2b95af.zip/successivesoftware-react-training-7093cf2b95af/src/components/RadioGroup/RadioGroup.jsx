import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { generateNewId } from '../../lib/utils';
import style from './style';

const defaultProps = {
  error: '',
  options: [],
};

const propTypes = {
  error: PropTypes.string,
  options: PropTypes.arrayOf(PropTypes.shape({
    label: PropTypes.string,
    value: PropTypes.string,
  })),
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
};

class RadioGroup extends Component {
  constructor(props) {
    super(props);

    this.radioId = generateNewId();
  }

  getLabelId = key => `${this.radioId}${key}`;

  render() {
    const {
      error,
      options,
      value,
      ...rest
    } = this.props;

    return (
      <>
        <div>
          {
            options.map(option => (
              <div key={option.value}>
                <label htmlFor={this.getLabelId(option.value)}>
                  <input
                    type="radio"
                    value={option.value}
                    id={this.getLabelId(option.value)}
                    checked={value === option.value}
                    {...rest}
                  />
                  { option.label }
                </label>
              </div>
            ))
          }
        </div>
        {
          error && (
            <div style={style.error}>{error}</div>
          )
        }
      </>
    );
  }
}

RadioGroup.defaultProps = defaultProps;
RadioGroup.propTypes = propTypes;

export default RadioGroup;
