export const PUBLIC_IMAGE_FOLDER = '/images/';
export const DEFAULT_BANNER_IMAGE = 'banners/default.png';


export const SPORT_CRICKET = 'cricket';
export const SPORT_FOOTBALL = 'football';

export const sports = [
  {
    value: SPORT_CRICKET,
    label: 'Cricket',
  },
  {
    value: SPORT_FOOTBALL,
    label: 'Football',
  },
];

export const cricketOptions = [
  {
    value: 'wk',
    label: 'Wicket Keeper',
  },
  {
    value: 'batsman',
    label: 'Batsman',
  },
  {
    value: 'bowler',
    label: 'Bowler',
  },
  {
    value: 'all-rounder',
    label: 'All Rounder',
  },
];

export const footballOptions = [
  {
    value: 'defender',
    label: 'Defender',
  },
  {
    value: 'striker',
    label: 'Striker',
  },
];
