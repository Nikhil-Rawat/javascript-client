import React from 'react';
import { MuiThemeProvider } from '@material-ui/core/styles';
import { CssBaseline } from '@material-ui/core';
import { BrowserRouter as Router, Switch } from 'react-router-dom';

import {
  Trainee,
  TextFieldDemo,
  InputDemo,
  ChildrenDemo,
  Login,
  NoMatch,
} from './pages';
import theme from './theme';
import { PrivateRoute, AuthRoute } from './routes';

const App = () => (
  <MuiThemeProvider theme={theme}>
    <CssBaseline />
    <Router>
      <Switch>
        <PrivateRoute exact path="/text-field-demo" component={TextFieldDemo} />
        <PrivateRoute exact path="/input-demo" component={InputDemo} />
        <PrivateRoute exact path="/children-demo" component={ChildrenDemo} />
        <AuthRoute exact path="/login" component={Login} />
        <PrivateRoute exact path="/" component={Trainee} />
        <PrivateRoute component={NoMatch} />
      </Switch>
    </Router>
  </MuiThemeProvider>
);

export default App;
