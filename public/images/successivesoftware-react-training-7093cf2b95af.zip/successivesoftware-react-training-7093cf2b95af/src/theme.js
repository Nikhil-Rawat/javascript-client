import { createMuiTheme } from '@material-ui/core/styles';

const theme = createMuiTheme({
  typography: {
    htmlFontSize: 16,
    fontFamily: '"Comic Sans MS", cursive, sans-serif',
  },
});

export default theme;
