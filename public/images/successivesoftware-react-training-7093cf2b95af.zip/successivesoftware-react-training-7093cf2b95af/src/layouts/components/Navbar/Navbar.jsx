import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

import {
  AppBar,
  Button,
  Toolbar,
  Typography,
  Link as MuiLInk,
} from '@material-ui/core';
import withStyles from '@material-ui/core/styles/withStyles';

const styles = theme => ({
  appBar: {
    position: 'relative',
  },
  logoutButton: {
    color: 'white',
  },
  toolbarTitle: {
    flex: 1,
  },
  items: {
    marginRight: theme.spacing.unit * 3,
  },
  link: {
    color: 'white',
  },
});

const propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
};

const routes = [
  {
    to: '/',
    label: 'Trainee',
  },
  {
    to: '/text-field-demo',
    label: 'Text Field Demo',
  },
  {
    to: '/input-demo',
    label: 'Input Demo',
  },
  {
    to: '/children-demo',
    label: 'Children Demo',
  },
];

class Navbar extends Component {
  renderLink = ({ to, label }) => {
    const { classes } = this.props;
    return (
      <MuiLInk component={Link} to={to} underline="none">
        <Button
          color="default"
          variant="text"
          className={classes.link}
        >
          {label}
        </Button>
      </MuiLInk>
    );
  }

  render() {
    const { classes } = this.props;

    return (
      <AppBar
        position="static"
        color="primary"
        className={classes.appBar}
      >
        <Toolbar>
          <Typography
            variant="h6"
            color="inherit"
            noWrap
            className={classes.toolbarTitle}
          >
            Trainee Portal
          </Typography>

          <div className={classes.items}>
            {
              routes.map(route => this.renderLink(route))
            }
          </div>
          <Button
            color="default"
            variant="text"
            className={classes.logoutButton}
          >
            Logout
          </Button>
        </Toolbar>
      </AppBar>
    );
  }
}

Navbar.propTypes = propTypes;

export default withStyles(styles)(Navbar);
