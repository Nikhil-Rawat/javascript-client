import React from 'react';
import PropTypes from 'prop-types';

import withStyles from '@material-ui/core/styles/withStyles';

const styles = theme => ({
  container: {
    marginTop: theme.spacing.unit * 5,
    textAlign: 'center',
  },
});

const propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
};

const Footer = (props) => {
  const { classes } = props;

  return (
    <div className={classes.container}>
      &copy; Successive Technologies
    </div>
  );
};

Footer.propTypes = propTypes;

export default withStyles(styles)(Footer);
