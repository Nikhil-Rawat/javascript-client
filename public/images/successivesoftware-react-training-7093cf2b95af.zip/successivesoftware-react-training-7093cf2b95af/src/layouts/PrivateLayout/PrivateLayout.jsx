import React from 'react';
import PropTypes from 'prop-types';
import withStyles from '@material-ui/core/styles/withStyles';

import { Navbar } from '../components';

const styles = theme => ({
  container: {
    margin: theme.spacing.unit * 3,
  },
});

const propTypes = {
  classes: PropTypes.objectOf(PropTypes.string).isRequired,
  children: PropTypes.node.isRequired,
};

const PrivateLayout = ({ children, classes }) => (
  <div>
    <Navbar />
    <div className={classes.container}>
      {children}
    </div>
  </div>
);

PrivateLayout.propTypes = propTypes;

export default withStyles(styles)(PrivateLayout);
