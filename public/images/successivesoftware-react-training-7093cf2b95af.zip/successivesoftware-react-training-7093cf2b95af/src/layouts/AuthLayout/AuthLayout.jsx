import React from 'react';
import PropTypes from 'prop-types';

import { Footer } from '../components';

const propTypes = {
  children: PropTypes.node.isRequired,
};

const AuthLayout = ({ children }) => (
  <div>
    <div>
      {children}
    </div>
    <Footer />
  </div>
);
AuthLayout.propTypes = propTypes;

export default AuthLayout;
